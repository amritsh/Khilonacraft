# Khilona Craft landing page

Static site: `index.html` + `assets/` (video, logo, poster). No build step.

## Put it live on GitHub Pages
1. Create a new GitHub repo (e.g. `khilonacraft`).
2. Upload everything in this folder to the repo root (keep `assets/` and `.nojekyll`).
3. Repo > Settings > Pages > Source: "Deploy from a branch", Branch: `main`, folder `/ (root)`. Save.
4. After about a minute the site is at `https://<your-username>.github.io/<repo>/`.
   For a custom domain, add it under Settings > Pages > Custom domain.

## Collect newsletter emails
The popup only saves emails in the visitor's own browser until you set `ENDPOINT` (near the bottom of
`index.html`) to a form URL from Formspree, Getform or similar.

## Optional
`COUNT_ENDPOINT` (same area) can point to a counter URL that returns {count} to show a worldwide spark count.
